<<?php 
$reservas = $conn->query("
    SELECT Marcações.*, Clientes.Nome AS ClienteNome, Serviços.Categoria AS ServicoCategoria
    FROM Marcações
    JOIN Clientes ON Marcações.Cliente_ID = Clientes.Cliente_ID
    JOIN Serviços ON Marcações.Servico_ID = Serviços.Servico_ID
    ORDER BY Data_Hora DESC
");
?>