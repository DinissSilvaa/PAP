<<?php 
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome = $_POST['nome'];
    $cargo = $_POST['cargo'];
    $email = $_POST['email'];
    $telefone = $_POST['telefone'];

    $query = $conn->prepare("INSERT INTO Funcionários (Nome, Cargo, Email, Telefone) VALUES (?, ?, ?, ?)");
    $query->execute([$nome, $cargo, $email, $telefone]);

    header('Location: funcionarios.php');
}
?>