<?php
// db_connection.php

// Define o nome ou IP do servidor onde está o MySQL (ex.: "localhost" para ambiente local)
$servername = "localhost";

// Define o nome de utilizador para aceder ao MySQL (ex.: "root" em ambiente local)
$username = "root";

// Define a palavra-passe para o MySQL (em muitos ambientes locais, pode estar vazia)
$password = "";

// Define o nome da base de dados onde estão ou estarão as tabelas do CRUD
$dbname = "PAP";

// Cria um novo objeto mysqli para estabelecer a conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verifica se houve erro na conexão
if ($conn->connect_error) {
    // Se sim, interrompe o programa e mostra a mensagem de erro
    die("Falha na conexão: " . $conn->connect_error);
}
// Se chegou até aqui sem erros, a variável $conn está pronta para usar nas queries SQL.
?>
