<?php
// forms/eliminar.php

// Inclui a conexão
require_once '../includes/db_connection.php';

// Verifica se o 'id' chegou pela query string
if (!isset($_GET['id'])) {
    echo "ID não especificado.";
    exit;
}

$id = $_GET['id'];

// Cria a query para eliminar o registo com este ID
$sql = "DELETE FROM pessoas WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);

// Tenta executar o DELETE
if ($stmt->execute()) {
    // Se funcionar, redireciona para a listagem
    header("Location: ../listar.php");
    exit;
} else {
    // Se houver erro, mostra mensagem
    echo "Erro ao eliminar registo: " . $conn->error;
}
?>
