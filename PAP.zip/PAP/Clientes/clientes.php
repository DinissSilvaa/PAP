<?php
require 'conexao.php'; // Inclui a conexão com o banco

// Busca os dados dos clientes
$query = $conn->query("SELECT * FROM Clientes ORDER BY Nome ASC");
$clientes = $query->fetchAll(PDO::FETCH_ASSOC);

?>
<?php 
$clientes = $conn->query("SELECT * FROM Clientes ORDER BY Nome ASC");
foreach ($clientes as $cliente) {
    echo "<tr>
            <td>{$cliente['Cliente_ID']}</td>
            <td>{$cliente['Nome']}</td>
            <td>{$cliente['Email']}</td>
            <td>{$cliente['Telefone']}</td>
            <td>
                <a href='editar_cliente.php?id={$cliente['Cliente_ID']}' class='btn btn-warning'>Editar</a>
                <a href='excluir_cliente.php?id={$cliente['Cliente_ID']}' class='btn btn-danger'>Excluir</a>
            </td>
          </tr>";
}
?>