<?php
// forms/adicionar.php

// Define o título da página
$pageTitle = "Adicionar Pessoa";

// Se quiseres CSS extra, podes definir no array $customStyles. Aqui, deixamos vazio.
$customStyles = [];

// Inclui a conexão com a base de dados para usar $conn
require_once '../includes/db_connection.php';

// Se o método do pedido for POST, então o formulário foi submetido
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Captura os valores enviados pelo formulário
    $nome  = $_POST['nome'];
    $email = $_POST['email'];

    // Cria a query INSERT com placeholders
    $sql = "INSERT INTO pessoas (nome, email) VALUES (?, ?)";
    
    // Prepara a instrução
    $stmt = $conn->prepare($sql);
    
    // "ss" significa que passamos duas strings (nome e email)
    $stmt->bind_param("ss", $nome, $email);
    
    // Executa a instrução
    if ($stmt->execute()) {
        // Se correr bem, redireciona para listar.php
        header("Location: ../listar.php");
        exit;
    } else {
        // Em caso de erro, mostra a mensagem
        echo "Erro ao inserir registo: " . $conn->error;
    }
    
    // Fecha a instrução
    $stmt->close();
}

// Inclui o header e o nav do layout
require_once '../templates/header.php';
require_once '../templates/nav.php';
?>

<!-- Conteúdo específico deste formulário -->
<div class="container mt-4">
    <h1>Adicionar Pessoa</h1>
    
    <!-- Form com classes do Bootstrap (p.ex. form-label, form-control) -->
    <form method="POST" action="" class="mt-3">
        <!-- Bloco de formulário com margin-bottom (mb-3) -->
        <div class="mb-3">
            <label for="nome" class="form-label">Nome:</label>
            <input 
                type="text" 
                class="form-control" 
                id="nome" 
                name="nome" 
                required
            >
        </div>
        
        <div class="mb-3">
            <label for="email" class="form-label">Email:</label>
            <input 
                type="email" 
                class="form-control" 
                id="email" 
                name="email" 
                required
            >
        </div>
        
        <!-- Botão principal (Salvar), com classe "btn btn-primary" -->
        <button type="submit" class="btn btn-primary">Adicionar</button>
        
        <!-- Botão/link para voltar à listagem, estilo Bootstrap -->
        <a href="../listar.php" class="btn btn-secondary">Voltar à Listagem</a>
    </form>
</div>

<?php
// Inclui o footer que encerra o HTML e carrega scripts JS
require_once '../templates/footer.php';
?>
