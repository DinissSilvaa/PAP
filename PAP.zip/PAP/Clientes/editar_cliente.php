<?php
// forms/editar.php

// Define título da página
$pageTitle = "Editar Pessoa";

// Define CSS extra se precisares
$customStyles = [];

// Inclui a conexão
require_once '../includes/db_connection.php';

// Verifica se existe o parâmetro 'id' via GET
if (!isset($_GET['id'])) {
    echo "ID não especificado.";
    exit;
}

$id = $_GET['id'];

// Busca o registo atual
$sql  = "SELECT * FROM pessoas WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$dados = $result->fetch_assoc();

// Se não encontrámos registo com este ID, paramos
if (!$dados) {
    echo "Registo não encontrado!";
    exit;
}

// Se o formulário foi submetido (POST), atualizamos no BD
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome  = $_POST['nome'];
    $email = $_POST['email'];

    $updateSql = "UPDATE pessoas SET nome = ?, email = ? WHERE id = ?";
    $updateStmt = $conn->prepare($updateSql);
    // "ssi" significa string, string, inteiro
    $updateStmt->bind_param("ssi", $nome, $email, $id);

    if ($updateStmt->execute()) {
        header("Location: ../listar.php");
        exit;
    } else {
        echo "Erro ao atualizar registo: " . $conn->error;
    }
    $updateStmt->close();
}

// Inclui o header e nav
require_once '../templates/header.php';
require_once '../templates/nav.php';
?>

<div class="container mt-4">
    <h1>Editar Pessoa</h1>

    <!-- Formulário pré-preenchido com os dados atuais -->
    <form method="POST" action="" class="mt-3">
        <div class="mb-3">
            <label for="nome" class="form-label">Nome:</label>
            <input
                type="text"
                class="form-control"
                id="nome"
                name="nome"
                required
                value="<?= $dados['nome']; ?>"
            >
        </div>

        <div class="mb-3">
            <label for="email" class="form-label">Email:</label>
            <input
                type="email"
                class="form-control"
                id="email"
                name="email"
                required
                value="<?= $dados['email']; ?>"
            >
        </div>

        <button type="submit" class="btn btn-primary">Atualizar</button>
        <a href="../listar.php" class="btn btn-secondary">Voltar à Listagem</a>
    </form>
</div>

<?php
// Inclui o footer
require_once '../templates/footer.php';
?>


<!-- Comentários sobre as classes do Bootstrap:

class="container mt-4":

container: Centraliza o conteúdo com margens automáticas e fornece padding horizontal.
mt-4: Aplica uma margem superior de 4 para espaçar do topo.
class="mb-4" em <h1>:

Aplica uma margem inferior de 4 para separar o título do formulário.
class="mt-3" no <form>:

Aplica uma margem superior de 3 para espaçar do título.
class="mb-3" nos <div>:

Aplica uma margem inferior de 3 para espaçar os grupos de formulário.
class="form-label" nas <label>:

Estiliza o rótulo com as classes padrão do Bootstrap para formulários.
class="form-control" nos <input>:

Aplica estilos de entrada do Bootstrap, como largura total, padding, bordas arredondadas, etc.
class="btn btn-primary" no <button>:

btn: Estiliza o elemento como um botão.
btn-primary: Aplica a cor primária (azul) do Bootstrap.
class="btn btn-secondary" no <a>:

Estiliza o link como um botão secundário (cinza) do Bootstrap. -->