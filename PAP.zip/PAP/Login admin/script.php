<?php 
session_start();
require 'conexao.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $senha = $_POST['senha'];

    $query = $conn->prepare("SELECT * FROM Admins WHERE Email = ?");
    $query->execute([$email]);
    $admin = $query->fetch();

    if ($admin && password_verify($senha, $admin['Senha'])) {
        $_SESSION['admin_id'] = $admin['Admin_ID'];
        header('Location: painel.php');
    } else {
        echo "Credenciais inválidas!";
    }
}
?>