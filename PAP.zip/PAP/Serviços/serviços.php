<?php 
$servicos = $conn->query("SELECT * FROM Serviços ORDER BY Categoria");
foreach ($servicos as $servico) {
    echo "<tr>
            <td>{$servico['Servico_ID']}</td>
            <td>{$servico['Categoria']}</td>
            <td>{$servico['Descricao']}</td>
            <td>{$servico['Preco']}</td>
            <td>
                <a href='editar_servico.php?id={$servico['Servico_ID']}' class='btn btn-warning'>Editar</a>
                <a href='excluir_servico.php?id={$servico['Servico_ID']}' class='btn btn-danger'>Excluir</a>
            </td>
          </tr>";
}
?>