<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $cliente_id = $_POST['cliente_id'];
    $servico_id = $_POST['servico_id'];
    $funcionario_id = $_POST['funcionario_id'];
    $data_hora = $_POST['data_hora'];

    $query = $conn->prepare("INSERT INTO Marcações (Cliente_ID, Servico_ID, Funcionario_ID, Data_Hora, Status) VALUES (?, ?, ?, ?, 'Pendente')");
    $query->execute([$cliente_id, $servico_id, $funcionario_id, $data_hora]);

    header('Location: reservas.php');
}
?>